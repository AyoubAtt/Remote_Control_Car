/**
  ******************************************************************************
  * @file    main.c
  * @author  Nirgal
  * @date    03-July-2019
  * @brief   Default main function.
  ******************************************************************************
*/
#include "stm32f1xx_hal.h"
#include "stm32f1_uart.h"
#include "stm32f1_sys.h"
#include "stm32f1_gpio.h"
#include "macro_types.h"
#include "systick.h"
#include "config.h"
#include "stm32f1_timer.h"
#include "stm32f1_pwm.h"
#include "stm32f1_extit.h"
#include "Voiture.h"
#include "HC-SR04/HCSR04.h"

#define P_HCSR04 100000
#define US_SPEED_IN_AIR			344	//mm/ms (� environ 20�)


uint8_t Rxdata[100];
static volatile uint32_t temps_ms;
uint32_t duree;
uint32_t distance;
int Flag=0;
char *p;


void writeLED(bool_e b)
{
	HAL_GPIO_WritePin(LED_GREEN_GPIO, LED_GREEN_PIN, b);
}

bool_e readButton(void)
{
	return !HAL_GPIO_ReadPin(BLUE_BUTTON_GPIO, BLUE_BUTTON_PIN);
}

static volatile uint32_t t = 0;
void process_ms(void)
{
	if(t)
		t--;
	temps_ms++;
}
uint32_t EXTI0_IRQHandler(void){ //recuperation de la duree du trajet entre l'obsatacle et le capteur ultrason
	static bool_e front_a= TRUE;
	__HAL_GPIO_EXTI_CLEAR_IT(GPIO_PIN_0);

	if(front_a){
		temps_ms= 0;
		BSP_GPIO_PinCfg(GPIOA,GPIO_PIN_0,GPIO_MODE_IT_FALLING,GPIO_PULLUP,GPIO_SPEED_FREQ_HIGH);
		front_a= !front_a;
	}
	else{
		duree = temps_ms;
		BSP_GPIO_PinCfg(GPIOA,GPIO_PIN_0,GPIO_MODE_IT_RISING,GPIO_PULLUP,GPIO_SPEED_FREQ_HIGH);
		front_a= !front_a;
	}
	return duree;
}

void state_voiture(void)
{							//Machine � etat de la voiture pour un controle bluetooth
  typedef enum
  {
    INIT,
    MODE_BT,
    DEPL_LINEAIRE,
    DEPL_DROIT,
    DEPL_ARRET,
    DEPL_GAUCHE
  }state_e;
  static state_e state = INIT;
  static state_e previous_state = INIT;
  bool_e entrance = (state!=previous_state);
  previous_state = state;

  switch(state)
  {
    case INIT:
      state = MODE_BT;
      printf("connected \n");

      break;
    case MODE_BT:
      if(UART_data_ready(UART2_ID))
      {
        char c;
        c = UART_getc(UART2_ID);
        switch(c)
        {
          case 'F':
            deplacement_lineaire(40);
            break;
          case 'B':
        	  marche_arriere();
        	  break;
          case 'R':
        	  deplacement_droit();
        	  break;
          case 'L':
        	  deplacement_gauche();
        	  break;
          case 'S':
        	  arret();
        	  break;
          default:
            break;
        }
      }
      break;
    case DEPL_LINEAIRE:
      if(entrance)
      {
        deplacement_lineaire(40);
        t = 1000;
      }
      if(!t)
        state = DEPL_DROIT;
      break;
    case DEPL_DROIT:
      if(entrance)
      {
        deplacement_droit();
        t = 1000;
      }
      if(!t)
        state = DEPL_ARRET;
      break;
    case DEPL_ARRET:
      if(entrance)
      {
        arret();
        t = 1000;
      }
      if(!t)
        state = DEPL_GAUCHE;

      break;
    case DEPL_GAUCHE:
      if(entrance)
      {
        deplacement_gauche();
        t = 1000;
      }
      if(!t)
        state = DEPL_LINEAIRE;

      break;
  }}

int main(void)
{
	//uint32_t periode= 200;
	//Initialisation de la couche logicielle HAL (Hardware Abstraction Layer)
	//Cette ligne doit rester la premi�re �tape de la fonction main().
	HAL_Init();


	//Initialisation de l'UART2 � la vitesse de 115200 bauds/secondes (92kbits/s) PA2 : Tx  | PA3 : Rx.
		//Attention, les pins PA2 et PA3 ne sont pas reli�es jusqu'au connecteur de la Nucleo.
		//Ces broches sont redirig�es vers la sonde de d�bogage, la liaison UART �tant ensuite encapsul�e sur l'USB vers le PC de d�veloppement.
	UART_init(UART2_ID,115200);

	//"Indique que les printf sortent vers le p�riph�rique UART2."
	SYS_set_std_usart(UART2_ID, UART2_ID, UART2_ID);

	//Initialisation du port de la led Verte (carte Nucleo)
	//BSP_GPIO_PinCfg(LED_GREEN_GPIO, LED_GREEN_PIN, GPIO_MODE_OUTPUT_PP,GPIO_NOPULL,GPIO_SPEED_FREQ_HIGH);

	//Initialisation du port du bouton bleu (carte Nucleo)
	//BSP_GPIO_PinCfg(BLUE_BUTTON_GPIO, BLUE_BUTTON_PIN, GPIO_MODE_INPUT,GPIO_PULLUP,GPIO_SPEED_FREQ_HIGH);

	//On ajoute la fonction process_ms � la liste des fonctions appel�es automatiquement chaque ms par la routine d'interruption du p�riph�rique SYSTICK
	Systick_add_callback_function(&process_ms);

	deplacement_init();

	 //PWM_run(TIMER4_ID,TIM_CHANNEL_3,FALSE,P_HCSR04,1,FALSE);// activation du capteur ultrason


	while(1)	//boucle de t�che de fond
	{

		/*distance = EXTI0_IRQHandler()*US_SPEED_IN_AIR;
		distance= distance/2;// calcule de la distance*/
		state_voiture();
		/*if(distance<=100){ // pour une certaine distance faire marche arriere
			arret();
			marche_arriere();
		}*/

	if(!t)
		{
			t = 200;

		}
	}
}
