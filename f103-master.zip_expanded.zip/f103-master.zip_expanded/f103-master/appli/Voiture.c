/*
 * Voiture.c
 *
 *  Created on: 23 fev. 2024
 *      Author: Utilisateur
 */

#include "Voiture.h"
#include "config.h"
#include "stm32f1_motorDC.h"
#include "stm32f1_pwm.h"
#include "stm32f1_gpio.h"
#include "stm32f1xx_hal.h"
#include "systick.h"


#define VITESSE_ROT 25
#define VITESSE_L   30

motor_id_e motor_g;
motor_id_e motor_d;
static volatile uint32_t t = 0;


void deplacement_init()
{																// initialisation des moteurs du vehicule
  motor_d = MOTOR_add(GPIOB, GPIO_PIN_6, GPIOB, GPIO_PIN_7);
  motor_g = MOTOR_add(GPIOA, GPIO_PIN_8, GPIOA, GPIO_PIN_9);
}

// les methodes suivantes permettent le depalcement du vehicule sous certaines conditions vers certaines directions
// ainsi que l'arr�t et le deplacement basique en modifiant le rapport cyclcique (RC)
//positif -> marche avant
//negatif-> marche arriere
void  deplacement(void){


      MOTOR_set_duty(motor_d, 30);
      MOTOR_set_duty(motor_g, 10);
      MOTOR_set_duty(motor_d ,0);
      MOTOR_set_duty(motor_g, -30);


}
void  deplacement_lineaire(void )
{
      MOTOR_set_duty(motor_d, VITESSE_L);
      MOTOR_set_duty(motor_g, VITESSE_L);
}


void  deplacement_droit(void){
     MOTOR_set_duty(motor_d, 50);
     MOTOR_set_duty(motor_g, -40);




}
void  deplacement_gauche(void){
      MOTOR_set_duty(motor_d, VITESSE_ROT);
    MOTOR_set_duty(motor_g, -VITESSE_ROT);

}


void  vitesse(void){

  motor_d = MOTOR_add(GPIOB, GPIO_PIN_6, GPIOB, GPIO_PIN_7);
  motor_g = MOTOR_add(GPIOB, GPIO_PIN_8, GPIOB, GPIO_PIN_9);
  while(1)
    {

      MOTOR_set_duty(motor_d, 50);
      MOTOR_set_duty(motor_g, 50);

    }



}
void  marche_arriere(void){

      MOTOR_set_duty(motor_d, -20);
      MOTOR_set_duty(motor_g, -10);


}
void  arret(void){
      MOTOR_set_duty(motor_d, 00);
      MOTOR_set_duty(motor_g, 00);

}
