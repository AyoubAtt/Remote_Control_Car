/*
 * Voiture.h
 *
 *  Created on: 23 fev. 2024
 *      Author: Utilisateur
 */

#ifndef VOITURE_H_
#define VOITURE_H_


#include "macro_types.h"
#include "stdint.h"

void  deplacement(void);
void  deplacement_lineaire();
void deplacement_droit(void);
void deplacement_gauche(void);
void  vitesse(void);
void  marche_arriere(void);
void  arret(void);
void deplacement_init(void);
#endif /* VOITURE_H_ */
